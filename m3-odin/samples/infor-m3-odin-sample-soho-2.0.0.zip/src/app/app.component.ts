import { Component } from '@angular/core';

@Component({
   selector: 'odin-app',
   template: '<router-outlet></router-outlet>'
})
export class AppComponent { }
