declare module 'highlight.js/lib/highlight';
declare module 'highlight.js/lib/languages/css';
declare module 'highlight.js/lib/languages/typescript';
declare module 'highlight.js/lib/languages/xml';
